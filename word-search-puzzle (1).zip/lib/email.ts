export async function sendVerificationEmail(email: string, token: string) {
  // In a real application, you would use an email service here
  console.log(`Sending verification email to ${email} with token ${token}`)
}

